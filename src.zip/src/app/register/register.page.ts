import { Component, OnInit } from '@angular/core';
import { AngularFireAuth } from '@angular/fire/auth';
import {NavController, AlertController} from '@ionic/angular';
import { auth } from 'firebase/app';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
})
export class RegisterPage implements OnInit {
  private username: string;
  private password: string;
  private cpassword: string;
  constructor(public afAuth: AngularFireAuth, public navCtrl: NavController, public alertCtrl: AlertController) { }

  ngOnInit() {
  }
  async register() {
    const { username, password, cpassword} = this
    if (password !== cpassword) {
      return console.error('passwords do not match');
    }
      const res = await this.afAuth.auth.createUserWithEmailAndPassword(username, password);
      console.log(res);
      this.navCtrl.navigateRoot('/login');
  }
  login() {
    this.navCtrl.navigateRoot('/login');
  }

}
