import { Component, OnInit } from '@angular/core';
import {NavController, AlertController} from '@ionic/angular';
import { AngularFireAuth } from '@angular/fire/auth';
import { auth } from 'firebase/app';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
})
export class LoginPage implements OnInit {

  private username: string;
  private password: any;
  constructor(public afAuth: AngularFireAuth, public navCtrl: NavController, public alertCtrl: AlertController) { }

  ngOnInit() {
  }
   async login() {
    const { username, password } = this
      const res = await this.afAuth.auth.signInWithEmailAndPassword(username, password);
      console.log('successful');
      this.navCtrl.navigateRoot('/home');
    }
    register() {
        this.navCtrl.navigateRoot('/register');
    }
}
