import {Component, OnInit} from '@angular/core';
import { Camera, CameraOptions } from '@ionic-native/camera/ngx';
import {NavController, AlertController} from '@ionic/angular';
import {PhotoService} from '../photo.service';
import { Storage } from '@ionic/storage';

@Component({
  selector: 'app-home',
  templateUrl: './home.page.html',
  styleUrls: ['./home.page.scss'],
})

export class HomePage {
  public photos: Photo[] = [];
  currentImage: any;
  constructor(private camera: Camera, public navCtrl: NavController, public alertCtrl: AlertController) { }
  logout() {
    this.navCtrl.navigateRoot('/login');
  }
  takePicture() {
    const options: CameraOptions = {
      quality: 100,
      destinationType: this.camera.DestinationType.DATA_URL,
      encodingType: this.camera.EncodingType.JPEG,
      mediaType: this.camera.MediaType.PICTURE
    }

    this.camera.getPicture(options).then((imageData) => {
      this.currentImage = 'data:image/jpeg;base64,' + imageData;
      // this.photos.unshift({
      //   data: 'data:image/jpeg;base64,' + imageData
      // });
    }, (err) => {
      // Handle error
      console.log('Camera issue:' + err);
    });
  }
}
class Photo {
  data: any;
}

