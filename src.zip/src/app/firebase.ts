const config = {
    apiKey: 'AIzaSyBffPpAOZT_eng5fc09Wnq5BTOBt5g57LA',
    authDomain: 'icp5-5db6f.firebaseapp.com',
    databaseURL: 'https://icp5-5db6f.firebaseio.com',
    projectId: 'icp5-5db6f',
    storageBucket: 'icp5-5db6f.appspot.com',
    messagingSenderId: '66781365870'
};

export default config
